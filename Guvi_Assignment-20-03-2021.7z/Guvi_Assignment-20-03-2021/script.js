// 1. create an instance xml http
var request = new XMLHttpRequest();
// 2. create/open connection
request.open('GET', 'https://restcountries.eu/rest/v2/all', true);
// 3. send request
request.send();
// 4. 
request.onload=function(){
    var data=JSON.parse(request.response);
    for(let i in data){
        console.log(data[i].name);

    }
}
