var arr = [2,4,6,7,8,9,1,3,7];
var prime = [];

(function () {
    for(let i in arr){
        var bool = true;
        for(let j=2;j<arr[i];j++){
            if(arr[i]%j===0)
                bool = false;
        }
        if(bool === true){
            prime.push(arr[i]);
        }
            
    }
    console.log(prime);
})();