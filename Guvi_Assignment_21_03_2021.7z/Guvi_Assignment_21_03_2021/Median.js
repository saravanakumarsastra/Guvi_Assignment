(function(){
    let arr1 = [5,4,3,2,1];
    let arr2 = [90,70,200,10,40];
    if(arr1.length === arr2.length){
        arr1.sort(function(a, b){return a-b});
        arr2.sort(function(a, b){return a-b});
        let newarr = [...arr1,...arr2];
        console.log(newarr[Math.floor(newarr.length/2)-1]);    
    }
    
})();
