var a = (function(){
    let arr1 = [5,4,3,2,1];
    let k = 2;
    for(var i=0;i<k;i++){
        arr1.unshift(arr1.pop());
    }
    return arr1;
})();

console.log(a);