var a = (function(){
    let arr1 = [5,4,3,2,1,9,2,1,4,5,2,3];
    let newarr = [];
    for(let i in arr1){
        var bool = true;
        for(let j in newarr){
            if(arr1[i] === newarr[j])
                bool = false;
        }
        if(bool)
            newarr.push(arr1[i]);
    }
    return newarr;
    
})();

console.log(a);